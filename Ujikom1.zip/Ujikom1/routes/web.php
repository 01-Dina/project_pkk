<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RegistrationController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::resource('registrations', RegistrationController::class);
//Route::resource('landings', LandingController::class);


Route::get('/landings', 'App\Http\Controllers\LandingController@index');
// Route::resource('landingpage', LandingpageController::class);

// Route::get('registrations', [RegistrationController::class, 'index'])->name('registrations.index');
// Route::get('registrations/create', [RegistrationController::class, 'create'])->name('registrations.create');
// Route::post('registrations/store', [RegistrationController::class, 'store'])->name('registrations.store');

// Route::get('registrations/edit/{id}', [RegistrationController::class, 'edit'])->name('registrations.edit');
// Route::post('registrations/{id}/update', [RegistrationController::class, 'update'])->name('registrations.update');

// Route::delete('registrations/{id}/delete', [RegistrationController::class, 'destroy'])->name('registrations.destroy');
Route::get('/exportpdf', [RegistrationController::class, 'export'])->name('exportpdf');
Route::get('/landingpage', [RegistrationController::class, 'landingpage'])->name('landingpageee');

//Route::get('/search/', 'RegistrationController@search')->name('search');
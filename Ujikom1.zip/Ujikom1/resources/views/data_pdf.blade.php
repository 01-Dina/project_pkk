<div class="row">
            <div class="pull-left">
                <h2>Pendaftaran Siswa</h2>
            </div>
     
    <table class="table table-bordered">
        <tr>
            <th>No. Daftar</th>
            <th>Nama Lengkap</th>
            <th>JK</th>
            <th>Alamat Lengkap</th>
            <th>Agama</th>
            <th>Asal SMP</th>
            <th>Jurusan</th>
        </tr>
    @php 
        $i = 1;
    @endphp
        @foreach ($data as $d)
        <tr>
            <td class="text-right">{{ $d->id }}</td>
            <td>{{ $d->nama }}</td>
            <td>{{ $d->jk }}</td>
            <td>{{ $d->alamat }}</td>
            <td>{{ $d->agama }}</td>
            <td>{{ $d->smp }}</td>
            <td>{{ $d->jurusan }}</td>
        </tr>
        @endforeach
    </table>

@extends('layouts.master')
  
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Ingin Merubah Data ?</h2>
            </div>
            <!--<div class="pull-right">
                <a class="btn btn-danger" href="#"> Kembali</a>
            </div> -->
        </div>
    </div>
    <br>  
    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
        
    <form action="{{ route('registrations.update',$registration->id) }}" method="POST" enctype="multipart/form-data"> 
        @csrf

        @method('PUT')
        
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Nama Lengkap</strong>
                    <input type="text" name="nama" class="form-control" placeholder="Input Nama Mu" value="{{$registration->nama}}">
                </div>
                <div class="form-group">
                    <strong>Jenis Kelamin</strong>
                    <select name="jk" class="form-select form-select-sm" aria-label=".form-select-sm example">
                    <option>Jenis Kelamin</option>
                    <option @if ($registration->jk == 'laki-laki') selected @endif value="laki-laki">Laki-Laki</option>
                    <option @if ($registration->jk == 'perempuan') selected @endif value="perempuan">Perempuan</option>
                    </select>
                </div>
                <div class="form-group">
                    <strong>Alamat Lengkap</strong>
                    <input type="text" name="alamat" class="form-control" placeholder="Tempat Tinggal Mu!"  value="{{$registration->alamat}}">
                </div>
                <div class="form-group">
                    <strong>Agama</strong>
                    <select name="agama" class="form-select form-select-sm" aria-label=".form-select-sm example">
                    <option>Agama</option>
                    <option @if ($registration->agama == 'islam') selected @endif value="islam">Islam</option>
                    <option @if ($registration->agama == 'kristen') selected @endif value="kristen">Kristen</option>
                    <option @if ($registration->agama == 'hindu') selected @endif value="hindu">Hindu</option>
                    <option @if ($registration->agama == 'budha') selected @endif value="budha">Budha</option>
                    <option @if ($registration->agama == 'katolik') selected @endif value="katolik">Katolik</option>
                    </select>
                </div>
                <div class="form-group">
                    <strong>Asal SMP</strong>
                    <input type="text" name="smp" class="form-control" placeholder="Sekolah asal Mu!"  value="{{$registration->smp}}"> 
                </div>
                <div class="form-group">
                    <strong>Jurusan</strong>
                    <select name="jurusan" class="form-select form-select-sm" aria-label=".form-select-sm example">
                    <option>Jurusan</option>
                    <option @if ($registration->jurusan == 'rekayasa perangkat lunak') selected @endif value="Rekayasa perangkat lunak">rekayasa perangkat lunak</option>
                    <option @if ($registration->jurusan == 'multimedia') selected @endif value="multimedia">Multimedia</option>
                    <option @if ($registration->jurusan == 'tkj') selected @endif value="tkj">TKJ</option>
                    <option @if ($registration->jurusan == 'otkp') selected @endif value="otkp">OTKP</option>
                    <option @if ($registration->jurusan == 'tata boga') selected @endif value="tata boga">Tata Boga</option>
                    <option @if ($registration->jurusan == 'pemasaran') selected @endif value="pemasaran">Pemasaran</option>
                    <option @if ($registration->jurusan == 'hotel') selected @endif value="hotel">Hotel</option>
                    </select>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <button type="submit" class="btn btn-success">Submit</button>
            </div>
        </div>
        
    </form>
@endsection
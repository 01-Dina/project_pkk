@extends('layouts.master')
     
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-right">
                <!-- <a class="btn btn-success" href="{{ route('registrations.create') }}"> Daftar</a> -->
                <a class="btn btn-success" href="/exportpdf"> Cetak PDF</a>
            </div>
        </div>
    </div>


    <br>
    <!-- <form action="" method="GET">
        <input type="text" name="search" required/>
        <button type="submit">Search</button>
    </form> -->


    <br>
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
     
    <table class="table table-bordered display" id="example">
    <thead>
        <tr>
            <th>No. Daftar</th>
            <th>Nama Lengkap</th>
            <th>JK</th>
            <th>Alamat Lengkap</th>
            <th>Agama</th>
            <th>Asal SMP</th>
            <th>Jurusan</th>
            <th width="280px">Action</th>
        </tr>
</thead>
<tbody>
        @foreach ($registrations as $registration)
       
        <tr>
            <td class="text-right">{{ $registration->id }}</td>
            <td>{{ $registration->nama }}</td>
            <td>{{ $registration->jk }}</td>
            <td>{{ $registration->alamat }}</td>
            <td>{{ $registration->agama }}</td>
            <td>{{ $registration->smp }}</td>
            <td>{{ $registration->jurusan }}</td>
            <td>
                <form action="{{ route('registrations.destroy',$registration->id) }}" method="POST">
           
                    <a class="btn btn-primary" href="{{ route('registrations.edit',$registration->id) }}">Edit</a>
     
                    @csrf
                    @method('DELETE')
        
                    <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah sudah Yakin')">Hapus</button>
                </form>
            </td>
        </tr>
        
        @endforeach
        <tbody>
    </table>
    
    {!! $registrations->links() !!}
        
@endsection
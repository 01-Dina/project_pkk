<div class="row">
            <div class="pull-left">
                <h2>Pendaftaran Siswa</h2>
            </div>
     
    <table class="table table-bordered">
        <tr>
            <th>No. Daftar</th>
            <th>Nama Lengkap</th>
            <th>JK</th>
            <th>Alamat Lengkap</th>
            <th>Agama</th>
            <th>Asal SMP</th>
            <th>Jurusan</th>
        </tr>
    <?php 
        $i = 1;
    ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-right"><?php echo e($d->id); ?></td>
            <td><?php echo e($d->nama); ?></td>
            <td><?php echo e($d->jk); ?></td>
            <td><?php echo e($d->alamat); ?></td>
            <td><?php echo e($d->agama); ?></td>
            <td><?php echo e($d->smp); ?></td>
            <td><?php echo e($d->jurusan); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php /**PATH C:\xampp\htdocs\Ujikom1\resources\views/data_pdf.blade.php ENDPATH**/ ?>
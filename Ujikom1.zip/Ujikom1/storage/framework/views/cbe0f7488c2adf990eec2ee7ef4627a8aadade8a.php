
  
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Ingin Merubah Data ?</h2>
            </div>
            <!--<div class="pull-right">
                <a class="btn btn-danger" href="#"> Kembali</a>
            </div> -->
        </div>
    </div>
    <br>  
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
        
    <form action="<?php echo e(route('registrations.update',$registration->id)); ?>" method="POST" enctype="multipart/form-data"> 
        <?php echo csrf_field(); ?>

        <?php echo method_field('PUT'); ?>
        
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Nama Lengkap</strong>
                    <input type="text" name="nama" class="form-control" placeholder="Input Nama Mu" value="<?php echo e($registration->nama); ?>">
                </div>
                <div class="form-group">
                    <strong>Jenis Kelamin</strong>
                    <select name="jk" class="form-select form-select-sm" aria-label=".form-select-sm example">
                    <option>Jenis Kelamin</option>
                    <option <?php if($registration->jk == 'laki-laki'): ?> selected <?php endif; ?> value="laki-laki">Laki-Laki</option>
                    <option <?php if($registration->jk == 'perempuan'): ?> selected <?php endif; ?> value="perempuan">Perempuan</option>
                    </select>
                </div>
                <div class="form-group">
                    <strong>Alamat Lengkap</strong>
                    <input type="text" name="alamat" class="form-control" placeholder="Tempat Tinggal Mu!"  value="<?php echo e($registration->alamat); ?>">
                </div>
                <div class="form-group">
                    <strong>Agama</strong>
                    <select name="agama" class="form-select form-select-sm" aria-label=".form-select-sm example">
                    <option>Agama</option>
                    <option <?php if($registration->agama == 'islam'): ?> selected <?php endif; ?> value="islam">Islam</option>
                    <option <?php if($registration->agama == 'kristen'): ?> selected <?php endif; ?> value="kristen">Kristen</option>
                    <option <?php if($registration->agama == 'hindu'): ?> selected <?php endif; ?> value="hindu">Hindu</option>
                    <option <?php if($registration->agama == 'budha'): ?> selected <?php endif; ?> value="budha">Budha</option>
                    <option <?php if($registration->agama == 'katolik'): ?> selected <?php endif; ?> value="katolik">Katolik</option>
                    </select>
                </div>
                <div class="form-group">
                    <strong>Asal SMP</strong>
                    <input type="text" name="smp" class="form-control" placeholder="Sekolah asal Mu!"  value="<?php echo e($registration->smp); ?>"> 
                </div>
                <div class="form-group">
                    <strong>Jurusan</strong>
                    <select name="jurusan" class="form-select form-select-sm" aria-label=".form-select-sm example">
                    <option>Jurusan</option>
                    <option <?php if($registration->jurusan == 'rekayasa perangkat lunak'): ?> selected <?php endif; ?> value="Rekayasa perangkat lunak">rekayasa perangkat lunak</option>
                    <option <?php if($registration->jurusan == 'multimedia'): ?> selected <?php endif; ?> value="multimedia">Multimedia</option>
                    <option <?php if($registration->jurusan == 'tkj'): ?> selected <?php endif; ?> value="tkj">TKJ</option>
                    <option <?php if($registration->jurusan == 'otkp'): ?> selected <?php endif; ?> value="otkp">OTKP</option>
                    <option <?php if($registration->jurusan == 'tata boga'): ?> selected <?php endif; ?> value="tata boga">Tata Boga</option>
                    <option <?php if($registration->jurusan == 'pemasaran'): ?> selected <?php endif; ?> value="pemasaran">Pemasaran</option>
                    <option <?php if($registration->jurusan == 'hotel'): ?> selected <?php endif; ?> value="hotel">Hotel</option>
                    </select>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <button type="submit" class="btn btn-success">Submit</button>
            </div>
        </div>
        
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ujikom1\resources\views/registrations/edit.blade.php ENDPATH**/ ?>
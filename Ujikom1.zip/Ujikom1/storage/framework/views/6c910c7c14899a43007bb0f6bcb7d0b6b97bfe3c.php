
     
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-right">
                <!-- <a class="btn btn-success" href="<?php echo e(route('registrations.create')); ?>"> Daftar</a> -->
                <a class="btn btn-success" href="/exportpdf"> Cetak PDF</a>
            </div>
        </div>
    </div>


    <br>
    <!-- <form action="" method="GET">
        <input type="text" name="search" required/>
        <button type="submit">Search</button>
    </form> -->


    <br>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
     
    <table class="table table-bordered display" id="example">
    <thead>
        <tr>
            <th>No. Daftar</th>
            <th>Nama Lengkap</th>
            <th>JK</th>
            <th>Alamat Lengkap</th>
            <th>Agama</th>
            <th>Asal SMP</th>
            <th>Jurusan</th>
            <th width="280px">Action</th>
        </tr>
</thead>
<tbody>
        <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
        <tr>
            <td class="text-right"><?php echo e($registration->id); ?></td>
            <td><?php echo e($registration->nama); ?></td>
            <td><?php echo e($registration->jk); ?></td>
            <td><?php echo e($registration->alamat); ?></td>
            <td><?php echo e($registration->agama); ?></td>
            <td><?php echo e($registration->smp); ?></td>
            <td><?php echo e($registration->jurusan); ?></td>
            <td>
                <form action="<?php echo e(route('registrations.destroy',$registration->id)); ?>" method="POST">
           
                    <a class="btn btn-primary" href="<?php echo e(route('registrations.edit',$registration->id)); ?>">Edit</a>
     
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
        
                    <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah sudah Yakin')">Hapus</button>
                </form>
            </td>
        </tr>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tbody>
    </table>
    
    <?php echo $registrations->links(); ?>

        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ujikom1\resources\views/registrations/index.blade.php ENDPATH**/ ?>
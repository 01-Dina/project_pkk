<?php

namespace App\Http\Controllers;

use App\Models\Registration;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\pdf;

class RegistrationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $registrations=Registration::latest()->paginate(5);
  
        return view('registrations.index',compact('registrations'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('registrations.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            
            'nama' => 'required',
            'jk' => 'required',
            'alamat' => 'required',
            'agama' => 'required',
            'smp' => 'required',
            'jurusan' => 'required',
        ]);
  
        Registration::create($request->all());
   
        return redirect()->route('registrations.index')
                        ->with('success','Berhasil Menyimpan !');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Registration  $registration
     * @return \Illuminate\Http\Response
     */
    public function show(Registration $registration)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Registration  $registration
     * @return \Illuminate\Http\Response
     */
    public function edit(Registration $registration)
    {
        return view('registrations.edit',compact('registration'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Registration  $registration
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Registration $registration)
    {
        $request->validate([
            'nama' => 'required',
            'jk' => 'required',
            'alamat' => 'required',
            'agama' => 'required',
            'smp' => 'required',
            'jurusan' => 'required',
        ]);
  
        $registration->update($request->all());
  
        return redirect()->route('registrations.index')
                        ->with('success','Berhasil Update !');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Registration  $registration
     * @return \Illuminate\Http\Response
     */
    public function destroy(Registration $registration)
    {
        $registration->delete();
  
        return redirect()->route('registrations.index')
                        ->with('success','Berhasil Hapus !');
    }

    public function export(){
        $data = Registration::all();

        view()->share('data', $data);
        $pdf = PDF::loadView('data_pdf');
        return $pdf->download('datasiswa.pdf');

    }

    public function landingpage()
    {
        return view('registrations.landingpage');
    }

    public function search(Request $request){
        $search = $request->input('search');
    
        $registrations = Registration::query()
            ->where('nama', 'LIKE', "%{$search}%")
            //->orWhere('body', 'LIKE', "%{$search}%")
            ->get();
    
        return view('registrations.index', compact('registrations'));
    }

}
